import asyncio
import html as _html
import logging
import os
import re
import sqlite3
import sys
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP
from urllib.parse import quote, urlencode

from aiogram import BaseMiddleware, Bot, Dispatcher, F, Router
from aiogram.client.default import Default, DefaultBotProperties
from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.enums import ParseMode
from aiogram.exceptions import (TelegramAPIError, TelegramBadRequest,
                                TelegramForbiddenError, TelegramRetryAfter)
from aiogram.filters import BaseFilter, Command, CommandObject, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (CallbackQuery, ErrorEvent, FSInputFile, InlineKeyboardButton,
                           InlineKeyboardMarkup, KeyboardButton, Message,
                           ReplyKeyboardMarkup)
from aiogram.utils.keyboard import InlineKeyboardBuilder

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _load_env(path: str) -> None:
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env(os.path.join(BASE_DIR, ".env"))

BOT_TOKEN = os.getenv("8754933145:AAGvWWgzNDDNoMQXcqd0CffKTfEobcHVVLQ", "8754933145:AAGvWWgzNDDNoMQXcqd0CffKTfEobcHVVLQ")
ADMIN_IDS = [int(x) for x in re.findall(r"\d+", os.getenv("8732373424", "8732373424"))]
GOLD_RATE = os.getenv("GOLD_RATE", "0.63")
MIN_DEPOSIT = os.getenv("MIN_DEPOSIT", "50")
MIN_WITHDRAW = os.getenv("MIN_WITHDRAW", "100")
MAX_WITHDRAW = os.getenv("MAX_WITHDRAW", "100000")
SUPPORT_URL = os.getenv("SUPPORT_URL", "")
SBP_URL = os.getenv("SBP_URL", "")
CARD_URL = os.getenv("CARD_URL", "")
RULES_URL = os.getenv("RULES_URL", "")
SKIN_PHOTO = os.path.join(BASE_DIR, "skin.jpg")
DB_PATH = os.getenv("TRASH_GOLD_DB", os.path.join(BASE_DIR, "trash_gold.db"))

MAX_GOLD = 10_000_000
MAX_RUB = Decimal("10000000")
PAGE = 8

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("trash_gold")
bot: Bot = None
BOT_USERNAME = ""

SEP = "━━━━━━━━━━━━━━"

WELCOME = ("😇 Добро пожаловать в Trash Gold!\n\n"
           "🏆 Лучший магазин по продаже голды для Standoff 2!\n\n"
           "👇 Выбирай нужный раздел в меню!")
WITHDRAW_TEXT = ("📤 <b>Вывод {gold} G</b>\n" + SEP + "\n\n"
                 "Выставьте скин {skin} за <b>{price}</b> до 2 голды.\n\n"
                 "После этого отправьте скриншот вашего выставленного скина 📸")

DEFAULTS = {
    "gold_rate": GOLD_RATE, "sbp_url": SBP_URL, "card_url": CARD_URL,
    "support_url": SUPPORT_URL, "rules_url": RULES_URL,
    "min_deposit": MIN_DEPOSIT, "min_withdraw": MIN_WITHDRAW, "max_withdraw": MAX_WITHDRAW,
    "welcome_text": WELCOME, "withdraw_text": WITHDRAW_TEXT,
    "withdraw_skin": 'MAC10 "Arid"', "withdraw_multiplier": "1.20076",
    "auto_convert": "1", "shop_open": "1",
    "ref_percent": "1", "clean_chat": "1",
}
SETTINGS_META = [
    ("gold_rate", "💱 Курс Gold (₽ за 1 G)", "dec"),
    ("sbp_url", "🔗 Ссылка СБП", "url"),
    ("card_url", "💳 Ссылка оплаты картой", "url"),
    ("support_url", "🛟 Ссылка поддержки", "url"),
    ("rules_url", "📜 Ссылка на правила", "url"),
    ("min_deposit", "⬇️ Мин. пополнение (₽)", "dec"),
    ("min_withdraw", "📤 Мин. вывод (G)", "int"),
    ("max_withdraw", "📤 Макс. вывод (G)", "int"),
    ("welcome_text", "👋 Текст приветствия", "text"),
    ("withdraw_text", "📝 Инструкция по выводу", "text"),
    ("withdraw_skin", "🔫 Скин для вывода", "text"),
    ("withdraw_multiplier", "✖️ Множитель цены скина", "dec"),
    ("auto_convert", "🔁 Пополнение → сразу в Gold", "bool"),
    ("shop_open", "🏪 Магазин открыт", "bool"),
    ("ref_percent", "👥 Бонус за друзей (%)", "dec"),
    ("clean_chat", "🗑 Чистка чата", "bool"),
]
META = {k: (label, typ) for k, label, typ in SETTINGS_META}

PREMIUM = {
    "⭐": "6034923938486684992", "💰": "5904359114531675993", "🪙": "5904462880941545555",
    "🆔": "6035084557378654059", "👤": "6035084557378654059", "🔢": "5764638872000533034",
    "📖": "6039584437564347225", "✅": "5774022692642492953", "🛟": "6030784887093464891",
    "🏠": "6042137469204303531", "📊": "5936143551854285132", "💱": "5769248574499983619",
    "🔄": "5769248574499983619", "🔁": "6030657343744644592", "🔗": "6028171274939797252",
    "👥": "6032609071373226027", "🧾": "6050643982646513651", "➕": "5882207227997066107",
    "🎁": "6032644646587338669", "📣": "6039450962865688331", "⚙": "6032742198179532882",
    "🛠": "5904258298764334001", "🔎": "6032850693348399258", "⏳": "5891211339170326418",
    "⌛": "5891211339170326418", "❌": "5774077015388852135", "✖": "5774077015388852135",
    "📤": "6039573425268201570", "💵": "5890848474563352982", "💸": "5902206159095339799",
    "🛒": "5920332557466997677", "🏪": "5920332557466997677", "📅": "5890937706803894250",
    "📆": "5890937706803894250", "📌": "6043896193887506430", "💳": "5769126056262898415",
    "🏷": "5890727932011223292", "🕓": "5775896410780079073", "💬": "6030784887093464891",
    "❓": "6030848053177486888", "🚫": "5938215362473496448", "✏": "6039779802741739617",
    "🗑": "6039522349517115015", "📜": "5766994197705921104", "🎉": "6041731551845159060",
    "🔒": "6037249452824072506", "📋": "6034969813032374911", "🚀": "5920515922505765329",
    "⚠": "6030563507299160824", "❗": "6030563507299160824", "📸": "6048390817033228573",
    "↩": "6039539366177541657", "⬅": "5960671702059848143", "🏆": "5805553606635559688", "😇": "6028315147754278596",
    "👇": "5886583490434044162", "📈": "5938539885907415367", "🆕": "5895669571058142797",
    "⬇": "6039802767931871481", "➡": "6037622221625626773", "📝": "5922693616953725714",
    "🔫": "5767356727305441799", "🔔": "6039486778597970865", "ℹ": "6028435952299413210",
    "✨": "5890925363067886150", "👋": "6041921818896372382", "💼": "5938492039971737551",
    "🎭": "6032625495328165724", "🔨": "6039729023343400390", "💎": "6037083366438737901",
    "👑": "5805553606635559688", "🤖": "6030400221232501136", "📢": "6021418126061605425",
    "⛔": "5938215362473496448", "👆": "5886583490434044162", "📛": "6035084557378654059",
    "🚦": "6030445631921721471", "🟢": "5774022692642492953", "🔴": "5774077015388852135",
}

_ALT = "|".join(sorted((re.escape(k) for k in PREMIUM), key=len, reverse=True))
_EMO_RE = re.compile("(" + _ALT + ")\uFE0F?")
_LEAD_RE = re.compile("^(" + _ALT + ")\uFE0F?\\s*(.+)$", re.S)
_TOK_RE = re.compile(r"(<tg-emoji\b[^>]*>.*?</tg-emoji>|<[^>]+>)", re.S)


def premium_html(text: str, limit: int = 90) -> str:
    out = []
    skip = 0
    count = 0

    def rep(m):
        nonlocal count
        if count >= limit:
            return m.group(0)
        count += 1
        return f'<tg-emoji emoji-id="{PREMIUM[m.group(1)]}">{m.group(0)}</tg-emoji>'

    for part in _TOK_RE.split(text):
        if not part:
            continue
        if part.startswith("<"):
            low = part.lower()
            if re.match(r"<(code|pre)\b", low):
                skip += 1
            elif re.match(r"</(code|pre)\b", low):
                skip = max(0, skip - 1)
            out.append(part)
            continue
        out.append(part if skip else _EMO_RE.sub(rep, part))
    return "".join(out)


def split_icon(text: str):
    m = _LEAD_RE.match(text)
    if not m:
        return text, None
    return m.group(2).strip(), PREMIUM[m.group(1)]


def IB(text: str, **kw) -> InlineKeyboardButton:
    clean, eid = split_icon(text)
    if eid:
        kw["icon_custom_emoji_id"] = eid
    return InlineKeyboardButton(text=clean, **kw)


class IKB(InlineKeyboardBuilder):
    def button(self, *, text: str, **kw):
        return self.add(IB(text=text, **kw))


class PremiumMW(BaseRequestMiddleware):
    FIELDS = {"SendMessage": "text", "EditMessageText": "text", "SendPhoto": "caption",
              "EditMessageCaption": "caption"}

    async def __call__(self, make_request, bot, method):
        attr = self.FIELDS.get(type(method).__name__)
        if attr:
            orig = getattr(method, attr, None)
            pm = getattr(method, "parse_mode", None)
            if isinstance(orig, str) and (isinstance(pm, Default) or pm == "HTML"):
                new = premium_html(orig)
                if new != orig:
                    try:
                        return await make_request(bot, method.model_copy(update={attr: new}))
                    except TelegramBadRequest:
                        pass
        return await make_request(bot, method)


class Interaction:
    """Один шаг диалога (сообщение/нажатие кнопки) в личке: что бот отправил в ответ."""

    def __init__(self, chat_id: int, keep: set):
        self.chat_id = chat_id
        self.keep = keep        # сообщения, которые нельзя удалять (источник нажатой кнопки)
        self.new = []           # id новых сообщений бота в этом чате
        self.hard = False       # было ли «настоящее» сообщение (не предупреждение ⚠️)
        self.muted = 0          # >0 — отправки не трогаем (уведомления)
        self.active = True


_IX: ContextVar = ContextVar("interaction", default=None)
_CHAT_LOCKS: dict = {}


@contextmanager
def keep_messages():
    """Сообщения, отправленные внутри блока, не считаются «экраном» и не удаляются при чистке."""
    ix = _IX.get()
    if ix is None:
        yield
        return
    ix.muted += 1
    try:
        yield
    finally:
        ix.muted -= 1


class TrackMW(BaseRequestMiddleware):
    """Запоминает сообщения бота, отправленные пользователю в ответ на его действие."""
    SENDERS = {"SendMessage", "SendPhoto"}

    async def __call__(self, make_request, bot, method):
        resp = await make_request(bot, method)
        ix = _IX.get()
        if (ix is not None and ix.active and not ix.muted and type(method).__name__ in self.SENDERS
                and getattr(method, "chat_id", None) == ix.chat_id):
            mid = getattr(getattr(resp, "result", None), "message_id", None)
            if mid:
                ix.new.append(mid)
                body = getattr(method, "text", None) or getattr(method, "caption", None) or ""
                if not re.sub(r"<[^>]+>", "", body).lstrip().startswith("⚠"):
                    ix.hard = True
        return resp


DB = sqlite3.connect(DB_PATH, isolation_level=None, check_same_thread=False)
DB.row_factory = sqlite3.Row
TABLES = {"dep": "deposits", "buy": "purchases", "wd": "withdrawals"}
OPEN = ("awaiting_payment", "checking", "pending")
STATUS = {
    "awaiting_payment": "⏳ Ожидает оплаты", "checking": "🔎 Оплата проверяется",
    "paid": "💵 Оплачено", "done": "✅ Выполнено",
    "pending": "⏳ Ожидает выполнения", "rejected": "❌ Отклонено",
}
STATUS_EMO = {"awaiting_payment": "⏳", "checking": "🔎", "paid": "💵",
              "done": "✅", "pending": "⏳", "rejected": "❌"}
FILTERS = {"a": None, "p": OPEN, "d": ("paid", "done"), "r": ("rejected",)}
TX_LABELS = {
    "deposit": "💰 Пополнение", "convert": "🔁 Конвертация ₽→G", "buy": "⭐ Покупка Gold",
    "buy_balance": "⭐ Покупка за баланс", "withdraw_hold": "📤 Вывод (заявка)",
    "withdraw_done": "✅ Вывод выполнен", "withdraw_refund": "↩️ Возврат по выводу",
    "promo": "🎁 Промокод", "admin_gold": "➕ Начисление админом",
    "admin_gold_sub": "➖ Списание админом", "admin_rub": "💰 Корректировка баланса",
    "ref_bonus": "👥 Бонус за друга",
}


def init_db() -> None:
    DB.execute("PRAGMA foreign_keys=ON")
    try:
        DB.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        pass
    DB.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, reg_date TEXT NOT NULL,
        gold INTEGER NOT NULL DEFAULT 0 CHECK(gold>=0),
        rub INTEGER NOT NULL DEFAULT 0 CHECK(rub>=0),
        banned INTEGER NOT NULL DEFAULT 0, referrer_id INTEGER)""")
    if "referrer_id" not in {r[1] for r in DB.execute("PRAGMA table_info(users)")}:
        DB.execute("ALTER TABLE users ADD COLUMN referrer_id INTEGER")
    DB.execute("CREATE INDEX IF NOT EXISTS ix_users_ref ON users(referrer_id)")
    DB.execute("""CREATE TABLE IF NOT EXISTS screen_msgs(
        chat_id INTEGER NOT NULL, msg_id INTEGER NOT NULL, PRIMARY KEY(chat_id, msg_id))""")
    DB.execute("CREATE INDEX IF NOT EXISTS ix_users_username ON users(LOWER(username))")
    DB.execute("""CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
        type TEXT NOT NULL, gold_delta INTEGER NOT NULL DEFAULT 0, rub_delta INTEGER NOT NULL DEFAULT 0,
        comment TEXT, ref TEXT, created TEXT NOT NULL)""")
    DB.execute("CREATE INDEX IF NOT EXISTS ix_tx_user ON transactions(user_id, id)")
    for t in TABLES.values():
        DB.execute(f"""CREATE TABLE IF NOT EXISTS {t}(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
            gold INTEGER NOT NULL DEFAULT 0 CHECK(gold>=0),
            amount_kop INTEGER NOT NULL DEFAULT 0 CHECK(amount_kop>=0),
            method TEXT, extra TEXT, status TEXT NOT NULL, proof TEXT, created TEXT NOT NULL,
            processed_by INTEGER, processed_at TEXT, reason TEXT)""")
        DB.execute(f"CREATE INDEX IF NOT EXISTS ix_{t}_user ON {t}(user_id)")
        DB.execute(f"CREATE INDEX IF NOT EXISTS ix_{t}_status ON {t}(status)")
    DB.execute("""CREATE TABLE IF NOT EXISTS promo_codes(
        id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE,
        gold INTEGER NOT NULL CHECK(gold>0), max_uses INTEGER NOT NULL CHECK(max_uses>0),
        used INTEGER NOT NULL DEFAULT 0, expires_at TEXT, active INTEGER NOT NULL DEFAULT 1,
        created TEXT NOT NULL)""")
    DB.execute("""CREATE TABLE IF NOT EXISTS promo_activations(
        id INTEGER PRIMARY KEY AUTOINCREMENT, promo_id INTEGER NOT NULL REFERENCES promo_codes(id),
        user_id INTEGER NOT NULL REFERENCES users(id), created TEXT NOT NULL,
        UNIQUE(promo_id, user_id))""")
    DB.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    DB.execute("CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY, added_at TEXT NOT NULL)")
    for k, v in DEFAULTS.items():
        DB.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, str(v)))
    for a in ADMIN_IDS:
        DB.execute("INSERT OR IGNORE INTO admins(user_id,added_at) VALUES(?,?)", (a, now()))


@contextmanager
def tx():
    DB.execute("BEGIN IMMEDIATE")
    try:
        yield DB
        DB.execute("COMMIT")
    except BaseException:
        DB.execute("ROLLBACK")
        raise


class BotError(Exception):
    pass


class AlreadyProcessed(BotError):
    pass


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def get_setting(key: str) -> str:
    r = DB.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else str(DEFAULTS.get(key, ""))


def set_setting(key: str, value) -> None:
    DB.execute("INSERT INTO settings(key,value) VALUES(?,?) "
               "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def rate() -> Decimal:
    try:
        r = Decimal(get_setting("gold_rate"))
        return r if r > 0 else Decimal("0.63")
    except Exception:
        return Decimal("0.63")


def gold_to_kop(g: int, rounding=ROUND_HALF_UP) -> int:
    return int((Decimal(g) * rate() * 100).quantize(Decimal(1), rounding))


def kop_to_gold(kop: int) -> int:
    return int((Decimal(kop) / 100 / rate()).to_integral_value(ROUND_FLOOR))


def ref_rate() -> Decimal:
    try:
        v = Decimal(get_setting("ref_percent"))
        return v / 100 if 0 < v <= 100 else Decimal("0.01")
    except Exception:
        return Decimal("0.01")


def pay_referral(uid: int, kind: str, oid: int, amount_kop: int):
    """Начисляет пригласившему % с оплаты друга (в рублях). Только внутри транзакции."""
    row = DB.execute("SELECT referrer_id FROM users WHERE id=?", (uid,)).fetchone()
    rid = row[0] if row else None
    if not rid or rid == uid:
        return None
    rate_ = ref_rate()
    bonus = int((Decimal(amount_kop) * rate_).to_integral_value(ROUND_FLOOR))
    if bonus <= 0:
        return None
    what = "пополнения" if kind == "dep" else "покупки"
    try:
        apply_balance(rid, 0, bonus, "ref_bonus", f"{fmt_dec(rate_ * 100)}% с {what} №{oid} (друг {uid})",
                      f"ref:{kind}:{oid}")
    except BotError:
        return None
    return rid, bonus


def get_user(uid: int):
    return DB.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def upsert_user(u) -> None:
    DB.execute("INSERT INTO users(id,username,first_name,reg_date) VALUES(?,?,?,?) "
               "ON CONFLICT(id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name",
               (u.id, u.username, u.first_name or "", now()))


def find_user(q: str):
    q = q.strip().lstrip("@")
    if q.isdigit():
        return get_user(int(q))
    return DB.execute("SELECT * FROM users WHERE LOWER(username)=?", (q.lower(),)).fetchone()


def all_admin_ids() -> set:
    ids = set(ADMIN_IDS)
    ids.update(r[0] for r in DB.execute("SELECT user_id FROM admins"))
    return ids


def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS or DB.execute("SELECT 1 FROM admins WHERE user_id=?", (uid,)).fetchone() is not None


def apply_balance(uid: int, dg: int = 0, dk: int = 0, ttype: str = "", comment: str = "", ref: str = "") -> None:
    if not DB.in_transaction:
        raise RuntimeError("apply_balance вне транзакции")
    if get_user(uid) is None:
        raise BotError("Пользователь не найден.")
    cur = DB.execute("UPDATE users SET gold=gold+?, rub=rub+? WHERE id=? AND gold+?>=0 AND rub+?>=0",
                     (dg, dk, uid, dg, dk))
    if cur.rowcount != 1:
        raise BotError("Недостаточно средств на балансе.")
    DB.execute("INSERT INTO transactions(user_id,type,gold_delta,rub_delta,comment,ref,created) VALUES(?,?,?,?,?,?,?)",
               (uid, ttype, dg, dk, comment, ref, now()))


def esc(s) -> str:
    return _html.escape("" if s is None else str(s))


def fmt_dec(d) -> str:
    return format(Decimal(d).normalize(), "f")


def fmt_rub(kop) -> str:
    s = f"{Decimal(int(kop)) / 100:,.2f}".replace(",", " ")
    if s.endswith(".00"):
        s = s[:-3]
    return f"{s} ₽"


def fmt_g(n) -> str:
    return f"{int(n):,}".replace(",", " ") + " G"


def uname(u) -> str:
    n = esc(u["first_name"] or "—")
    return f"{n} (@{esc(u['username'])})" if u["username"] else n


def fmt_dt(s) -> str:
    return esc(s or "—")


_NUM = r"(\d+(?:[.,]\d+)?)"
_UNIT = r"(₽|р\.?|руб\w*|rub|g|г|гол\w*|gold)"


def _clean(t: str) -> str:
    return re.sub(r"\s+", "", (t or "").lower())


def parse_dec(text: str, hi: Decimal = Decimal("1000000000")) -> Decimal:
    t = _clean(text)
    if t.startswith("-"):
        raise ValueError("Число не может быть отрицательным.")
    m = re.fullmatch(_NUM + _UNIT + "?", t)
    if not m:
        raise ValueError("Введите число, например 500.")
    v = Decimal(m.group(1).replace(",", "."))
    if v == 0:
        raise ValueError("Значение должно быть больше нуля.")
    if v > hi:
        raise ValueError("Слишком большое значение.")
    return v


def parse_int(text: str, lo: int = 1, hi: int = MAX_GOLD) -> int:
    v = parse_dec(text, Decimal(hi))
    if v != v.to_integral_value():
        raise ValueError("Нужно целое число.")
    i = int(v)
    if i < lo:
        raise ValueError(f"Минимум: {lo}.")
    return i


def parse_rub(text: str, lo: Decimal = Decimal("0.01")) -> Decimal:
    v = parse_dec(text, MAX_RUB).quantize(Decimal("0.01"), ROUND_HALF_UP)
    if v < lo:
        raise ValueError(f"Минимальная сумма: {fmt_dec(lo)} ₽.")
    return v


def parse_signed_rub(text: str) -> Decimal:
    t = _clean(text)
    sign = -1 if t.startswith("-") else 1
    body = t.lstrip("+-")
    v = parse_rub(body)
    return v * sign


def norm_url(raw: str) -> str:
    raw = raw.strip()
    if raw.startswith("@") and re.fullmatch(r"@[A-Za-z0-9_]{4,}", raw):
        return "https://t.me/" + raw[1:]
    if raw.lower().startswith(("t.me/", "telegram.me/")):
        raw = "https://" + raw
    if not re.match(r"^(https?://|tg://)\S+$", raw):
        raise ValueError("Нужна ссылка вида https://... (или @username).")
    if len(raw) > 500:
        raise ValueError("Ссылка слишком длинная.")
    return raw


def validate_setting(key: str, raw: str) -> str:
    typ = META[key][1]
    raw = raw.strip()
    if typ == "url":
        return "" if raw == "-" else norm_url(raw)
    if typ == "dec":
        v = parse_dec(raw, Decimal("1000000")).quantize(Decimal("0.00001"), ROUND_HALF_UP)
        if v <= 0:
            raise ValueError("Значение слишком мало.")
        if key == "ref_percent" and v > 100:
            raise ValueError("Процент не может быть больше 100.")
        return fmt_dec(v)
    if typ == "int":
        v = parse_int(raw, 1, MAX_GOLD)
        if key == "min_withdraw" and v > int(get_setting("max_withdraw")):
            raise ValueError("Минимум не может быть больше максимума.")
        if key == "max_withdraw" and v < int(get_setting("min_withdraw")):
            raise ValueError("Максимум не может быть меньше минимума.")
        return str(v)
    if typ == "text":
        if not raw or len(raw) > 3000:
            raise ValueError("Текст должен быть от 1 до 3000 символов.")
        return raw
    raise ValueError("Неизвестный тип настройки.")


def withdraw_price(g: int) -> Decimal:
    mult = Decimal(get_setting("withdraw_multiplier") or "1")
    return (Decimal(g) * mult).quantize(Decimal("0.01"), ROUND_HALF_UP)


BTN_BUY, BTN_SELL, BTN_WD = "Купить Голду", "Продать Голду", "Вывести"
BTN_DEP, BTN_PROFILE, BTN_CALC = "Пополнить", "Профиль", "Посчитать"
BTN_HELP, BTN_ABOUT, BTN_SUPPORT = "Помощь и ответы", "О боте", "Поддержка"
BTN_HOME = "Главное меню"
A_STATS, A_RATE, A_SBP, A_USERS = "Статистика", "Изменить курс", "Ссылка СБП", "Пользователи"
A_PAY, A_WD, A_GIVE, A_PROMO = "Заявки на оплату", "Заявки на вывод", "Начислить Gold", "Создать промокод"
A_BC, A_SET = "Рассылка", "Настройки"
BTN_ICON = {
    BTN_BUY: "⭐", BTN_SELL: "⭐", BTN_WD: "⭐", BTN_DEP: "💰", BTN_PROFILE: "🆔", BTN_CALC: "🔢",
    BTN_HELP: "📖", BTN_ABOUT: "✅", BTN_SUPPORT: "🛟", BTN_HOME: "🏠",
    A_STATS: "📊", A_RATE: "💱", A_SBP: "🔗", A_USERS: "👥", A_PAY: "🧾", A_WD: "⭐",
    A_GIVE: "➕", A_PROMO: "🎁", A_BC: "📣", A_SET: "⚙",
}


def KB(text: str) -> KeyboardButton:
    eid = PREMIUM.get(BTN_ICON.get(text, ""))
    if eid:
        return KeyboardButton(text=text, icon_custom_emoji_id=eid)
    return KeyboardButton(text=text)


def main_kb() -> ReplyKeyboardMarkup:
    rows = [[BTN_BUY], [BTN_WD, BTN_DEP], [BTN_CALC, BTN_ABOUT, BTN_HELP], [BTN_SELL, BTN_SUPPORT, BTN_PROFILE]]
    return ReplyKeyboardMarkup(keyboard=[[KB(t) for t in r] for r in rows],
                               resize_keyboard=True, input_field_placeholder="Выберите раздел 👇")


def admin_kb() -> ReplyKeyboardMarkup:
    rows = [[A_STATS, A_RATE], [A_SBP, A_USERS], [A_PAY, A_WD], [A_GIVE, A_PROMO], [A_BC, A_SET], [BTN_HOME]]
    return ReplyKeyboardMarkup(keyboard=[[KB(t) for t in r] for r in rows],
                               resize_keyboard=True, input_field_placeholder="Админ-панель")


def home_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[IB(text="🏠 Главное меню", callback_data="home")]])


def url_btn(text: str, url: str, fallback_cb: str = "nolink") -> InlineKeyboardButton:
    return IB(text=text, url=url) if url else IB(text=text, callback_data=fallback_cb)


def pay_kb(kind: str, oid: int, method: str = None) -> InlineKeyboardMarkup:
    rows = []
    if method is None:
        if kind == "buy":
            rows.append([IB(text="💼 Оплатить с баланса", callback_data=f"bpay:{oid}")])
        rows.append([IB(text="💳 Оплатить картой", callback_data=f"pm:{kind}:{oid}:card"),
                     IB(text="🔗 Оплатить через СБП", callback_data=f"pm:{kind}:{oid}:sbp")])
    else:
        link = get_setting("card_url" if method == "card" else "sbp_url")
        rows.append([url_btn("➡️ Перейти к оплате", link)])
        rows.append([IB(text="📸 Я оплатил — отправить скриншот", callback_data=f"pp:{kind}:{oid}")])
        rows.append([IB(text="↩️ Сменить способ", callback_data=f"pb:{kind}:{oid}")])
    rows.append([IB(text="🗑 Отменить заявку", callback_data=f"pc:{kind}:{oid}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


class BuyS(StatesGroup):
    amount = State()


class DepS(StatesGroup):
    amount = State()


class WdS(StatesGroup):
    amount = State()
    shot = State()


class ProofS(StatesGroup):
    photo = State()


class CalcS(StatesGroup):
    input = State()


class PromoS(StatesGroup):
    code = State()


class AdminS(StatesGroup):
    rate = State()
    search = State()
    adjust = State()
    give_id = State()
    give_amount = State()
    reason = State()
    setting = State()
    promo_code = State()
    promo_gold = State()
    promo_uses = State()
    promo_days = State()


class BcS(StatesGroup):
    content = State()
    buttons = State()
    confirm = State()


TEXT_STATES = [BuyS.amount, DepS.amount, WdS.amount, CalcS.input, PromoS.code]


class AdminFilter(BaseFilter):
    async def __call__(self, event) -> bool:
        u = getattr(event, "from_user", None)
        return bool(u and is_admin(u.id))


async def safe_send(chat_id: int, text: str, **kw):
    with keep_messages():
        return await _safe_send(chat_id, text, **kw)


async def _safe_send(chat_id: int, text: str, **kw):
    for attempt in (1, 2):
        try:
            return await bot.send_message(chat_id, text, **kw)
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 0.5)
        except TelegramBadRequest:
            try:
                return await bot.send_message(chat_id, text, parse_mode=None, **kw)
            except TelegramAPIError as e2:
                log.warning("send to %s failed: %s", chat_id, e2)
                return None
        except TelegramAPIError as e:
            log.warning("send to %s failed: %s", chat_id, e)
            return None
    return None


async def html_answer(m: Message, text: str, **kw):
    try:
        return await m.answer(text, **kw)
    except TelegramBadRequest:
        return await m.answer(text, parse_mode=None, **kw)


async def edit_any(cb: CallbackQuery, text: str, kb=None) -> None:
    if not cb.message:
        return
    try:
        if cb.message.photo or cb.message.caption:
            await cb.message.edit_caption(caption=text, reply_markup=kb)
        else:
            await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest as e:
        if "not modified" not in str(e):
            log.warning("edit failed: %s", e)


def welcome_text() -> str:
    return f"{get_setting('welcome_text')}\n\n💱 Курс: 1 G = <b>{fmt_dec(rate())} ₽</b>"


def shop_closed_for(uid: int) -> bool:
    return get_setting("shop_open") != "1" and not is_admin(uid)


CLOSED_TEXT = "🔒 Магазин временно закрыт. Попробуйте позже или напишите в поддержку."


def get_order(kind: str, oid: int):
    return DB.execute(f"SELECT * FROM {TABLES[kind]} WHERE id=?", (oid,)).fetchone()


def order_text(kind: str, o) -> str:
    u = get_user(o["user_id"])
    title = {"dep": "💰 Пополнение", "buy": "⭐ Покупка Gold", "wd": "📤 Вывод Gold"}[kind]
    L = [f"<b>{title} №{o['id']}</b>", SEP, f"👤 {uname(u) if u else o['user_id']}", f"🆔 <code>{o['user_id']}</code>"]
    if o["gold"]:
        L.append(f"🪙 Gold: <b>{fmt_g(o['gold'])}</b>")
    L.append(f"💵 Сумма: <b>{fmt_rub(o['amount_kop'])}</b>")
    if o["method"]:
        L.append(f"💳 Способ оплаты: {esc({'card': 'Карта', 'sbp': 'СБП', 'balance': 'Баланс'}.get(o['method'], o['method']))}")
    if kind == "wd" and o["extra"]:
        L.append(f"🏷 Цена скина: {esc(o['extra'])}")
    L.append(f"📅 Создана: {fmt_dt(o['created'])}")
    L.append(f"📌 Статус: {STATUS.get(o['status'], o['status'])}")
    if o["processed_at"]:
        L.append(f"🕓 Обработана: {fmt_dt(o['processed_at'])} (админ {o['processed_by']})")
    if o["reason"]:
        L.append(f"💬 Причина: {esc(o['reason'])}")
    return "\n".join(L)


def order_admin_kb(kind: str, o):
    if o["status"] not in OPEN:
        return None
    b = IKB()
    b.button(text="✅ Я выполнил" if kind == "wd" else "✅ Подтвердить оплату", callback_data=f"ok:{kind}:{o['id']}")
    b.button(text="❌ Отклонить", callback_data=f"no:{kind}:{o['id']}")
    b.adjust(2)
    return b.as_markup()


async def notify_admins_order(kind: str, oid: int) -> None:
    o = get_order(kind, oid)
    text = "🔔 <b>Новая заявка</b>\n" + order_text(kind, o)
    kb = order_admin_kb(kind, o)
    with keep_messages():
        for aid in all_admin_ids():
            try:
                if o["proof"]:
                    await bot.send_photo(aid, o["proof"], caption=text, reply_markup=kb)
                else:
                    await bot.send_message(aid, text, reply_markup=kb)
            except TelegramAPIError as e:
                log.warning("notify admin %s failed: %s", aid, e)


def finalize_order(kind: str, oid: int, admin_id: int):
    T = TABLES[kind]
    ref_bonus = None
    with tx():
        o = get_order(kind, oid)
        if o is None:
            raise BotError("Заявка не найдена.")
        cur = DB.execute(f"UPDATE {T} SET status='done', processed_by=?, processed_at=? "
                         f"WHERE id=? AND status IN ('awaiting_payment','checking','pending')", (admin_id, now(), oid))
        if cur.rowcount != 1:
            raise AlreadyProcessed("Заявка уже обработана.")
        uid = o["user_id"]
        ref = f"{kind}:{oid}"
        if kind == "dep":
            apply_balance(uid, 0, o["amount_kop"], "deposit", f"Пополнение №{oid}", ref)
            msg = f"✅ <b>Баланс пополнен на {fmt_rub(o['amount_kop'])}</b> (заявка №{oid})."
            if get_setting("auto_convert") == "1":
                g = kop_to_gold(o["amount_kop"])
                if g > 0:
                    spent = gold_to_kop(g, ROUND_FLOOR)
                    apply_balance(uid, g, -spent, "convert", f"{fmt_rub(spent)} → {fmt_g(g)} по курсу {fmt_dec(rate())}", ref)
                    msg += f"\n🔁 Зачислено <b>{fmt_g(g)}</b> по курсу 1 G = {fmt_dec(rate())} ₽.\nМожно выводить: «{BTN_WD}»."
            else:
                msg += f"\nКупить Gold можно в разделе «{BTN_BUY}»."
            ref_bonus = pay_referral(uid, "dep", oid, o["amount_kop"])
        elif kind == "buy":
            apply_balance(uid, o["gold"], 0, "buy", f"Покупка №{oid} ({fmt_rub(o['amount_kop'])})", ref)
            msg = (f"✅ <b>Покупка №{oid} выполнена!</b>\nНа баланс зачислено <b>{fmt_g(o['gold'])}</b>.\n"
                   f"Вывести: «{BTN_WD}».")
            ref_bonus = pay_referral(uid, "buy", oid, o["amount_kop"])
        else:
            apply_balance(uid, 0, 0, "withdraw_done", f"Вывод №{oid}: {fmt_g(o['gold'])}", ref)
            msg = f"✅ <b>Вывод №{oid} выполнен!</b>\n{fmt_g(o['gold'])} отправлены. Спасибо, что выбрали Trash Gold! 🏆"
    return uid, msg, ref_bonus


def reject_order(kind: str, oid: int, admin_id: int, reason: str):
    T = TABLES[kind]
    with tx():
        o = get_order(kind, oid)
        if o is None:
            raise BotError("Заявка не найдена.")
        cur = DB.execute(f"UPDATE {T} SET status='rejected', processed_by=?, processed_at=?, reason=? "
                         f"WHERE id=? AND status IN ('awaiting_payment','checking','pending')",
                         (admin_id, now(), reason or None, oid))
        if cur.rowcount != 1:
            raise AlreadyProcessed("Заявка уже обработана.")
        if kind == "wd" and o["gold"] > 0:
            apply_balance(o["user_id"], o["gold"], 0, "withdraw_refund", f"Возврат по выводу №{oid}", f"wd:{oid}")
    msg = f"❌ <b>Заявка №{oid} отклонена.</b>"
    if reason:
        msg += f"\n💬 Причина: {esc(reason)}"
    if kind == "wd":
        msg += f"\n↩️ {fmt_g(o['gold'])} возвращены на баланс."
    msg += "\nЕсли это ошибка — напишите в поддержку."
    return o["user_id"], msg


def admin_adjust(uid: int, mode: str, amount: Decimal, admin_id: int):
    with tx():
        if mode == "gold_add":
            apply_balance(uid, int(amount), 0, "admin_gold", f"Админ {admin_id}")
            text = f"🎁 Вам начислено <b>{fmt_g(amount)}</b>."
        elif mode == "gold_sub":
            apply_balance(uid, -int(amount), 0, "admin_gold_sub", f"Админ {admin_id}")
            text = f"➖ С вашего баланса списано <b>{fmt_g(amount)}</b>."
        else:
            kop = int(amount * 100)
            apply_balance(uid, 0, kop, "admin_rub", f"Админ {admin_id}")
            text = f"💰 Баланс скорректирован: <b>{'+' if kop > 0 else '−'}{fmt_rub(abs(kop))}</b>."
    return get_user(uid), text + "\nПроверьте профиль."


def activate_promo(uid: int, code: str) -> int:
    code = code.strip().upper()
    with tx():
        p = DB.execute("SELECT * FROM promo_codes WHERE code=?", (code,)).fetchone()
        if p is None:
            raise BotError("Промокод не найден.")
        if not p["active"]:
            raise BotError("Промокод отключён.")
        if p["expires_at"] and p["expires_at"] < now():
            raise BotError("Срок действия промокода истёк.")
        if DB.execute("SELECT 1 FROM promo_activations WHERE promo_id=? AND user_id=?", (p["id"], uid)).fetchone():
            raise BotError("Вы уже активировали этот промокод.")
        cur = DB.execute("UPDATE promo_codes SET used=used+1 WHERE id=? AND used<max_uses", (p["id"],))
        if cur.rowcount != 1:
            raise BotError("Лимит активаций промокода исчерпан.")
        DB.execute("INSERT INTO promo_activations(promo_id,user_id,created) VALUES(?,?,?)", (p["id"], uid, now()))
        apply_balance(uid, p["gold"], 0, "promo", code)
    return p["gold"]


def profile_text(u) -> str:
    def c(sql: str) -> int:
        return DB.execute(sql, (u["id"],)).fetchone()[0]
    buys = c("SELECT COUNT(*) FROM purchases WHERE user_id=? AND status='done'")
    sells = c("SELECT COUNT(*) FROM withdrawals WHERE user_id=? AND status='done'")
    deps = c("SELECT COUNT(*) FROM deposits WHERE user_id=? AND status='done'")
    wds = c("SELECT COUNT(*) FROM withdrawals WHERE user_id=?")
    return (f"🆔 <b>Профиль</b>\n{SEP}\n"
            f"👤 Имя: {esc(u['first_name'] or '—')}\n"
            f"🔗 Username: {('@' + esc(u['username'])) if u['username'] else '—'}\n"
            f"🆔 Telegram ID: <code>{u['id']}</code>\n"
            f"📅 Регистрация: {fmt_dt(u['reg_date'])}\n{SEP}\n"
            f"💰 Баланс ₽: <b>{fmt_rub(u['rub'])}</b>\n"
            f"🪙 Баланс Gold: <b>{fmt_g(u['gold'])}</b>\n{SEP}\n"
            f"🛒 Покупок: {buys}\n💸 Продаж: {sells}\n➕ Пополнений: {deps}\n📤 Выводов (заявок): {wds}")


def history_text(uid: int, limit: int = 20) -> str:
    rows = DB.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, limit)).fetchall()
    if not rows:
        return "📜 <b>История операций</b>\n\nОпераций пока нет."
    L = [f"📜 <b>История операций</b> (последние {len(rows)})", SEP]
    for r in rows:
        parts = []
        if r["gold_delta"]:
            parts.append(f"{r['gold_delta']:+d} G")
        if r["rub_delta"]:
            parts.append(("+" if r["rub_delta"] > 0 else "−") + fmt_rub(abs(r["rub_delta"])))
        L.append(f"{esc(r['created'])}\n{TX_LABELS.get(r['type'], esc(r['type']))} {' / '.join(parts)}"
                 + (f"\n<i>{esc(r['comment'])}</i>" if r["comment"] else ""))
    return "\n".join(L[:2]) + "\n\n" + "\n\n".join(L[2:])


def stats_text() -> str:
    c = lambda sql, *a: DB.execute(sql, a).fetchone()[0]
    today = datetime.now().strftime("%Y-%m-%d 00:00:00")
    week = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
    done = sum(c(f"SELECT COUNT(*) FROM {t} WHERE status='done'") for t in TABLES.values())
    wait = sum(c(f"SELECT COUNT(*) FROM {t} WHERE status IN ('awaiting_payment','checking','pending')") for t in TABLES.values())
    return (f"📊 <b>Статистика</b>\n{SEP}\n"
            f"👥 Всего пользователей: <b>{c('SELECT COUNT(*) FROM users')}</b>\n"
            f"🆕 Новых за сегодня: <b>{c('SELECT COUNT(*) FROM users WHERE reg_date>=?', today)}</b>\n"
            f"📆 Новых за неделю: <b>{c('SELECT COUNT(*) FROM users WHERE reg_date>=?', week)}</b>\n{SEP}\n"
            f"🪙 Gold на балансах: <b>{fmt_g(c('SELECT COALESCE(SUM(gold),0) FROM users'))}</b>\n"
            f"💰 Объём пополнений: <b>{fmt_rub(c('SELECT COALESCE(SUM(amount_kop),0) FROM deposits WHERE status=?', 'done'))}</b>\n"
            f"📤 Объём выводов: <b>{fmt_g(c('SELECT COALESCE(SUM(gold),0) FROM withdrawals WHERE status=?', 'done'))}</b>"
            f" ({fmt_rub(c('SELECT COALESCE(SUM(amount_kop),0) FROM withdrawals WHERE status=?', 'done'))})\n{SEP}\n"
            f"🧾 Заявок на пополнение: <b>{c('SELECT COUNT(*) FROM deposits')}</b>\n"
            f"⭐ Заявок на вывод: <b>{c('SELECT COUNT(*) FROM withdrawals')}</b>\n"
            f"🛒 Заявок на покупку: <b>{c('SELECT COUNT(*) FROM purchases')}</b>\n"
            f"✅ Выполнено заявок: <b>{done}</b>\n"
            f"⏳ Ожидают: <b>{wait}</b>")


def list_view(kind: str, flt: str, page: int):
    T = TABLES[kind]
    st = FILTERS[flt]
    where, params = "", []
    if st:
        where, params = "WHERE status IN (%s)" % ",".join("?" * len(st)), list(st)
    total = DB.execute(f"SELECT COUNT(*) FROM {T} {where}", params).fetchone()[0]
    pages = max(1, (total + PAGE - 1) // PAGE)
    page = max(0, min(page, pages - 1))
    rows = DB.execute(f"SELECT * FROM {T} {where} ORDER BY id DESC LIMIT ? OFFSET ?", params + [PAGE, page * PAGE]).fetchall()
    title = {"dep": "🧾 Заявки на пополнение", "buy": "🧾 Заявки на покупку", "wd": "⭐ Заявки на вывод"}[kind]
    fname = {"a": "все", "p": "ожидающие", "d": "выполненные", "r": "отклонённые"}[flt]
    text = f"<b>{title}</b>\nФильтр: <b>{fname}</b> • всего: {total} • стр. {page + 1}/{pages}"
    if not rows:
        text += "\n\nПусто."
    b = IKB()
    for o in rows:
        amt = fmt_g(o["gold"]) if kind == "wd" else fmt_rub(o["amount_kop"])
        b.row(IB(text=f"{STATUS_EMO.get(o['status'], '•')} №{o['id']} • {amt} • id{o['user_id']}",
                                   callback_data=f"po:{kind}:{o['id']}"))
    fl = [IB(text=("• " if k == flt else "") + lbl, callback_data=f"ol:{kind}:{k}:0")
          for k, lbl in (("a", "Все"), ("p", "⏳ Ожидающие"), ("d", "✅ Выполненные"), ("r", "❌ Отклонённые"))]
    b.row(fl[0], fl[1])
    b.row(fl[2], fl[3])
    nav = []
    if page > 0:
        nav.append(IB(text="⬅️ Назад", callback_data=f"ol:{kind}:{flt}:{page - 1}"))
    if page < pages - 1:
        nav.append(IB(text="➡️ Далее", callback_data=f"ol:{kind}:{flt}:{page + 1}"))
    if nav:
        b.row(*nav)
    b.row(IB(text="✖️ Закрыть", callback_data="close"))
    return text, b.as_markup()


def user_card(u):
    text = (f"👤 <b>Пользователь</b>\n{SEP}\n🆔 <code>{u['id']}</code>\n"
            f"🔗 Username: {('@' + esc(u['username'])) if u['username'] else '—'}\n"
            f"📛 Имя: {esc(u['first_name'] or '—')}\n"
            f"🪙 Gold: <b>{fmt_g(u['gold'])}</b>\n💰 Рубли: <b>{fmt_rub(u['rub'])}</b>\n"
            f"📅 Регистрация: {fmt_dt(u['reg_date'])}\n"
            f"🚦 Статус: {'🚫 заблокирован' if u['banned'] else '✅ активен'}")
    uid = u["id"]
    b = IKB()
    b.button(text="➕ Начислить Gold", callback_data=f"ug:{uid}")
    b.button(text="➖ Списать Gold", callback_data=f"us:{uid}")
    b.button(text="💰 Изменить баланс", callback_data=f"ur:{uid}")
    b.button(text="📜 История", callback_data=f"uh:{uid}")
    b.button(text="✅ Разблокировать" if u["banned"] else "🚫 Заблокировать",
             callback_data=f"uu:{uid}" if u["banned"] else f"ub:{uid}")
    b.adjust(2, 2, 1)
    return text, b.as_markup()


class UserMW(BaseMiddleware):
    async def __call__(self, handler, event, data):
        u = getattr(event, "from_user", None)
        if u and not u.is_bot:
            try:
                data["is_new_user"] = get_user(u.id) is None
                upsert_user(u)
                row = get_user(u.id)
                if row["banned"] and not is_admin(u.id):
                    if isinstance(event, CallbackQuery):
                        await event.answer("🚫 Вы заблокированы.", show_alert=True)
                    else:
                        await event.answer("🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку.")
                    return None
            except sqlite3.Error:
                log.exception("user upsert failed")
        return await handler(event, data)


async def _delete_msgs(chat_id: int, ids) -> None:
    ids = list(dict.fromkeys(ids))
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        try:
            await bot.delete_messages(chat_id, chunk)
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 0.5)
            try:
                await bot.delete_messages(chat_id, chunk)
            except TelegramAPIError:
                pass
        except TelegramAPIError:
            for mid in chunk:
                try:
                    await bot.delete_message(chat_id, mid)
                except TelegramAPIError:
                    pass


class CleanMW(BaseMiddleware):
    """Чистит чат: после ответа бота удаляет его прошлые «экраны» и сообщение пользователя."""

    async def __call__(self, handler, event, data):
        if isinstance(event, CallbackQuery):
            msg = event.message
            keep = {msg.message_id} if msg else set()
        else:
            msg, keep = event, set()
        chat = getattr(msg, "chat", None)
        if chat is None or chat.type != "private" or get_setting("clean_chat") != "1":
            return await handler(event, data)
        lock = _CHAT_LOCKS.setdefault(chat.id, asyncio.Lock())
        async with lock:
            ix = Interaction(chat.id, keep)
            token = _IX.set(ix)
            try:
                return await handler(event, data)
            finally:
                ix.active = False
                _IX.reset(token)
                try:
                    await self.finish(event, ix)
                except Exception:
                    log.exception("clean chat failed")

    async def finish(self, event, ix: Interaction) -> None:
        if not ix.new:
            return
        old = [r[0] for r in DB.execute("SELECT msg_id FROM screen_msgs WHERE chat_id=?", (ix.chat_id,))]
        kill = [i for i in old if i not in ix.keep] if ix.hard else []
        if isinstance(event, Message):
            kill.append(event.message_id)
        if kill:
            await _delete_msgs(ix.chat_id, kill)
            DB.executemany("DELETE FROM screen_msgs WHERE chat_id=? AND msg_id=?",
                           [(ix.chat_id, i) for i in kill])
        DB.executemany("INSERT OR IGNORE INTO screen_msgs(chat_id,msg_id) VALUES(?,?)",
                       [(ix.chat_id, i) for i in ix.new])


nav = Router()
adm = Router()
flow = Router()
fb = Router()
adm.message.filter(AdminFilter())
adm.callback_query.filter(AdminFilter())

CALC_TEXT = ("🔢 <b>Посчитать</b>\n\nВ ₽, в G\n\n"
             "В голду, например, <code>500 голды</code>, <code>400₽</code>\n"
             "В рублях, например, <code>400₽</code>, <code>500 голды</code>.\n\n"
             "Отправьте число с пометкой — <code>500 голды</code> (узнать цену в ₽) или "
             "<code>400₽</code> (узнать, сколько G). Либо выберите режим кнопкой, тогда хватит просто числа.")

FAQ = [
    ("Как купить Gold?", "Нажмите «⭐ Купить Голду», введите количество, оплатите заявку (картой, СБП или с баланса) "
                         "и отправьте скриншот оплаты. После проверки админом Gold будет зачислен на ваш баланс."),
    ("Как пополнить баланс?", "Нажмите «💰 Пополнить», введите сумму в рублях, выберите «Карта» или «СБП», оплатите "
                              "и отправьте скриншот. Деньги зачисляются после ручной проверки администратором."),
    ("Как вывести Gold?", "Нажмите «⭐ Вывести», введите количество G. Бот покажет, какой скин и за какую цену выставить. "
                          "Отправьте скриншот выставленного скина — админ выполнит заявку и нажмёт «Я выполнил»."),
    ("Сколько времени занимает обработка?", "Обычно заявки обрабатываются в течение нескольких минут, "
                                            "в редких случаях — до нескольких часов."),
    ("Как работает приглашение друзей?", "В «Профиле» нажмите «Пригласить Друга» и отправьте другу свою ссылку. "
                                           "Вы получаете процент со всех его пополнений и покупок пожизненно — "
                                           "бонус автоматически приходит на ваш рублёвый баланс."),
    ("Как связаться с поддержкой?", "Нажмите кнопку «🛟 Поддержка» в меню или кнопку ниже."),
]


def support_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[url_btn("🛟 Написать в поддержку", get_setting("support_url"))]])


@nav.message(CommandStart())
async def cmd_start(m: Message, state: FSMContext, command: CommandObject, is_new_user: bool = False):
    await state.clear()
    mm = re.fullmatch(r"ref_(\d{1,15})", (command.args or "").strip())
    if mm and is_new_user:
        rid = int(mm.group(1))
        if rid != m.from_user.id and get_user(rid):
            cur = DB.execute("UPDATE users SET referrer_id=? WHERE id=? AND referrer_id IS NULL", (rid, m.from_user.id))
            if cur.rowcount == 1:
                await safe_send(rid, "👥 <b>Новый друг!</b>\nПо вашей ссылке зашёл новый пользователь. "
                                     f"Вы будете получать {fmt_dec(ref_rate() * 100)}% с его покупок.")
    await html_answer(m, welcome_text(), reply_markup=main_kb())


@nav.message(Command("cancel"))
@nav.message(F.text == BTN_HOME)
async def go_home(m: Message, state: FSMContext):
    await state.clear()
    await html_answer(m, "🏠 <b>Меню</b>\n\n" + welcome_text(), reply_markup=main_kb())


@nav.message(Command("help"))
@nav.message(F.text == BTN_HELP)
async def help_menu(m: Message, state: FSMContext):
    await state.clear()
    b = IKB()
    for i, (q, _) in enumerate(FAQ):
        b.button(text=f"❓ {q}", callback_data=f"faq:{i}")
    b.adjust(1)
    b.row(url_btn("🛟 Поддержка", get_setting("support_url")))
    await m.answer("📖 <b>Помощь и ответы</b>\n\nВыберите вопрос:", reply_markup=b.as_markup())


@nav.message(F.text == BTN_ABOUT)
async def about(m: Message, state: FSMContext):
    await state.clear()
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        url_btn("📜 Правила", get_setting("rules_url"), "norules"),
        url_btn("🛟 Поддержка", get_setting("support_url"))]])
    await html_answer(m, "🏠 <b>Меню</b>\n\n" + welcome_text(), reply_markup=kb)


@nav.message(F.text == BTN_SUPPORT)
async def support(m: Message, state: FSMContext):
    await state.clear()
    if get_setting("support_url"):
        await m.answer("🛟 Если нужна помощь — напишите нам:", reply_markup=support_kb())
    else:
        await m.answer("🛟 Ссылка на поддержку ещё не настроена администратором.")


def profile_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [IB(text="📜 История операций", callback_data="hist"), IB(text="🎁 Промокод", callback_data="promo")],
        [IB(text="👥 Пригласить Друга", callback_data="invite")]])


def invite_link(uid: int) -> str:
    return f"https://t.me/{BOT_USERNAME}?start=ref_{uid}"


def invite_view(uid: int):
    friends = DB.execute("SELECT COUNT(*) FROM users WHERE referrer_id=?", (uid,)).fetchone()[0]
    earned = DB.execute("SELECT COALESCE(SUM(rub_delta),0) FROM transactions WHERE user_id=? AND type='ref_bonus'",
                        (uid,)).fetchone()[0]
    link = invite_link(uid)
    text = (f"👥 <b>Пригласить друга</b>\n{SEP}\n🔗 Ваша ссылка:\n<code>{link}</code>\n\n"
            f"🎁 Вы получаете <b>{fmt_dec(ref_rate() * 100)}%</b> пожизненно с пополнений и покупок друга, "
            "который зашёл в бота по вашей ссылке. Бонус приходит автоматически на ваш рублёвый баланс "
            "и тратится на покупку Gold («Оплатить с баланса»).\n"
            f"{SEP}\n👥 Приглашено друзей: <b>{friends}</b>\n💰 Заработано: <b>{fmt_rub(earned)}</b>")
    share = "https://t.me/share/url?" + urlencode(
        {"url": link, "text": "🏆 Trash Gold — лучший магазин голды для Standoff 2! Заходи по моей ссылке"},
        quote_via=quote)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [IB(text="➡️ Поделиться ссылкой", url=share)],
        [IB(text="↩️ Назад в профиль", callback_data="profback")]])
    return text, kb


@nav.message(F.text == BTN_PROFILE)
async def profile(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(profile_text(get_user(m.from_user.id)), reply_markup=profile_kb())


@flow.callback_query(F.data == "invite")
async def cb_invite(cb: CallbackQuery):
    await cb.answer()
    text, kb = invite_view(cb.from_user.id)
    await edit_any(cb, text, kb)


@flow.callback_query(F.data == "profback")
async def cb_profback(cb: CallbackQuery):
    await cb.answer()
    await edit_any(cb, profile_text(get_user(cb.from_user.id)), profile_kb())


@nav.message(Command("promo"))
async def cmd_promo(m: Message, state: FSMContext):
    await state.clear()
    parts = (m.text or "").split(maxsplit=1)
    if len(parts) == 2:
        await do_promo(m, parts[1])
    else:
        await state.set_state(PromoS.code)
        await m.answer("🎁 Введите промокод:", reply_markup=home_kb())


@nav.message(F.text == BTN_CALC)
async def calc_start(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(CalcS.input)
    await state.update_data(mode=None)
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        IB(text="🪙 G → ₽", callback_data="calc:g"),
        IB(text="₽ → G", callback_data="calc:r")],
        [IB(text="🏠 Главное меню", callback_data="home")]])
    await m.answer(CALC_TEXT + f"\n\n💱 Курс: 1 G = <b>{fmt_dec(rate())} ₽</b>", reply_markup=kb)


@nav.message(F.text == BTN_BUY)
async def buy_start(m: Message, state: FSMContext):
    await state.clear()
    if shop_closed_for(m.from_user.id):
        return await m.answer(CLOSED_TEXT)
    await state.set_state(BuyS.amount)
    await m.answer(f"⭐ <b>Покупка Gold</b>\n{SEP}\n💱 Курс: 1 G = <b>{fmt_dec(rate())} ₽</b>\n\n"
                   "Введите количество Gold, которое хотите купить:", reply_markup=home_kb())


@nav.message(F.text == BTN_DEP)
async def dep_start(m: Message, state: FSMContext):
    await state.clear()
    if shop_closed_for(m.from_user.id):
        return await m.answer(CLOSED_TEXT)
    await state.set_state(DepS.amount)
    await m.answer(f"💰 <b>Пополнение баланса</b>\n{SEP}\nМинимум: {fmt_dec(Decimal(get_setting('min_deposit')))} ₽\n\n"
                   "Введите сумму пополнения в рублях:", reply_markup=home_kb())


@nav.message(F.text.in_({BTN_WD, BTN_SELL}))
async def wd_start(m: Message, state: FSMContext):
    await state.clear()
    if shop_closed_for(m.from_user.id):
        return await m.answer(CLOSED_TEXT)
    u = get_user(m.from_user.id)
    mn, mx = int(get_setting("min_withdraw")), int(get_setting("max_withdraw"))
    if u["gold"] < mn:
        return await m.answer(f"❌ Недостаточно Gold для вывода.\n🪙 Ваш баланс: <b>{fmt_g(u['gold'])}</b>\n"
                              f"📤 Минимум для вывода: <b>{fmt_g(mn)}</b>\n\n"
                              f"Пополните баланс или купите Gold.")
    await state.set_state(WdS.amount)
    await m.answer(f"📤 <b>Вывод Gold</b>\n{SEP}\n🪙 Доступно: <b>{fmt_g(u['gold'])}</b>\n"
                   f"От {fmt_g(mn)} до {fmt_g(mx)}\n\nСколько Gold вы хотите вывести?", reply_markup=home_kb())


@flow.message(StateFilter(*TEXT_STATES), ~F.text)
async def need_text(m: Message):
    await m.answer("⚠️ Отправьте текстовое сообщение.")


@flow.message(BuyS.amount)
async def buy_amount(m: Message, state: FSMContext):
    try:
        g = parse_int(m.text, 1, MAX_GOLD)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    kop = gold_to_kop(g)
    oid = DB.execute("INSERT INTO purchases(user_id,gold,amount_kop,status,created) VALUES(?,?,?,?,?)",
                     (m.from_user.id, g, kop, "awaiting_payment", now())).lastrowid
    await state.clear()
    await m.answer(f"🧾 <b>Заявка на покупку №{oid}</b>\n{SEP}\n🪙 Gold: <b>{fmt_g(g)}</b>\n"
                   f"💵 К оплате: <b>{fmt_rub(kop)}</b>\n💱 Курс: 1 G = {fmt_dec(rate())} ₽\n{SEP}\n"
                   "<b>Как оплатить:</b>\n1. Выберите способ оплаты (или оплатите с баланса).\n"
                   "2. Оплатите точную сумму.\n3. Нажмите «Я оплатил» и отправьте скриншот.\n"
                   "Админ проверит оплату и подтвердит заявку.\n\n"
                   f"📌 Статус: {STATUS['awaiting_payment']}", reply_markup=pay_kb("buy", oid))


@flow.message(DepS.amount)
async def dep_amount(m: Message, state: FSMContext):
    try:
        v = parse_rub(m.text, Decimal(get_setting("min_deposit")))
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    kop = int(v * 100)
    oid = DB.execute("INSERT INTO deposits(user_id,gold,amount_kop,status,created) VALUES(?,?,?,?,?)",
                     (m.from_user.id, 0, kop, "awaiting_payment", now())).lastrowid
    await state.clear()
    await m.answer(f"🧾 <b>Заявка на пополнение №{oid}</b>\n{SEP}\n💵 Сумма: <b>{fmt_rub(kop)}</b>\n{SEP}\n"
                   "Выберите способ оплаты, оплатите и отправьте скриншот подтверждения. "
                   "Баланс пополнится после проверки администратором.\n\n"
                   f"📌 Статус: {STATUS['awaiting_payment']}", reply_markup=pay_kb("dep", oid))


@flow.message(WdS.amount)
async def wd_amount(m: Message, state: FSMContext):
    u = get_user(m.from_user.id)
    mn, mx = int(get_setting("min_withdraw")), int(get_setting("max_withdraw"))
    try:
        g = parse_int(m.text, mn, mx)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}\nДопустимо: от {fmt_g(mn)} до {fmt_g(mx)}.")
    if g > u["gold"]:
        return await m.answer(f"❌ Недостаточно Gold. Ваш баланс: <b>{fmt_g(u['gold'])}</b>.")
    price = fmt_dec(withdraw_price(g))
    await state.set_state(WdS.shot)
    await state.update_data(gold=g, price=price)
    text = (get_setting("withdraw_text").replace("{gold}", str(g)).replace("{price}", price)
            .replace("{skin}", get_setting("withdraw_skin")))
    await send_skin_instruction(m, text)


async def send_skin_instruction(m: Message, text: str) -> None:
    if os.path.exists(SKIN_PHOTO) and len(text) <= 1024:
        cached = get_setting("skin_photo_id")
        for src in ([cached] if cached else []) + [FSInputFile(SKIN_PHOTO)]:
            try:
                sent = await m.answer_photo(src, caption=text, reply_markup=home_kb())
                if not cached or src is not cached:
                    set_setting("skin_photo_id", sent.photo[-1].file_id)
                return
            except TelegramBadRequest:
                continue
            except TelegramAPIError as e:
                log.warning("skin photo failed: %s", e)
                break
    await html_answer(m, text, reply_markup=home_kb())


@flow.message(WdS.shot, F.photo)
async def wd_shot(m: Message, state: FSMContext):
    d = await state.get_data()
    g, price = int(d["gold"]), d["price"]
    fid = m.photo[-1].file_id
    try:
        with tx():
            kop = gold_to_kop(g)
            oid = DB.execute("INSERT INTO withdrawals(user_id,gold,amount_kop,extra,status,proof,created) "
                             "VALUES(?,?,?,?,?,?,?)", (m.from_user.id, g, kop, price, "pending", fid, now())).lastrowid
            apply_balance(m.from_user.id, -g, 0, "withdraw_hold", f"Заявка на вывод №{oid}", f"wd:{oid}")
    except BotError as e:
        await state.clear()
        return await m.answer(f"❌ {e}")
    await state.clear()
    await m.answer(f"✅ <b>Заявка на вывод №{oid} создана!</b>\n{SEP}\n🪙 {fmt_g(g)} • 💵 {fmt_rub(kop)}\n"
                   f"📌 Статус: {STATUS['pending']}\n\nGold зарезервированы на вашем балансе. "
                   "Мы уведомим вас, когда админ выполнит заявку.")
    await notify_admins_order("wd", oid)


@flow.message(ProofS.photo, F.photo)
async def proof_photo(m: Message, state: FSMContext):
    d = await state.get_data()
    kind, oid = d["kind"], int(d["oid"])
    fid = m.photo[-1].file_id
    cur = DB.execute(f"UPDATE {TABLES[kind]} SET proof=?, status='checking' "
                     "WHERE id=? AND user_id=? AND status IN ('awaiting_payment','checking')", (fid, oid, m.from_user.id))
    await state.clear()
    if cur.rowcount != 1:
        return await m.answer("⚠️ Эта заявка уже закрыта.")
    await m.answer(f"✅ Скриншот получен. Заявка №{oid} — {STATUS['checking']}.\nМы сообщим о результате.")
    await notify_admins_order(kind, oid)


@flow.message(WdS.shot)
@flow.message(ProofS.photo)
async def need_photo(m: Message):
    await m.answer("⚠️ Отправьте скриншот именно фотографией (не файлом и не текстом).")


@flow.message(CalcS.input)
async def calc_input(m: Message, state: FSMContext):
    mode = (await state.get_data()).get("mode")
    t = _clean(m.text)
    mm = re.fullmatch(_NUM + _UNIT + "?", t)
    if t.startswith("-"):
        return await m.answer("⚠️ Число не может быть отрицательным.")
    if not mm:
        return await m.answer("⚠️ Введите число, например <code>500 голды</code> или <code>400₽</code>.")
    v = Decimal(mm.group(1).replace(",", "."))
    if v == 0 or v > Decimal("1000000000"):
        return await m.answer("⚠️ Введите значение больше нуля и не слишком большое.")
    unit = mm.group(2)
    is_rub = (unit[0] in "₽рr") if unit else (mode == "r")
    r = rate()
    if is_rub:
        g = (v / r).quantize(Decimal("0.01"), ROUND_HALF_UP)
        res = f"💰 {fmt_dec(v)} ₽ ÷ {fmt_dec(r)} = <b>{fmt_dec(g)} G</b>"
    else:
        rub = (v * r).quantize(Decimal("0.01"), ROUND_HALF_UP)
        res = f"🪙 {fmt_dec(v)} G × {fmt_dec(r)} = <b>{fmt_dec(rub)} ₽</b>"
    await m.answer(f"🔢 <b>Результат</b>\n{SEP}\n{res}\n{SEP}\n💱 Курс: 1 G = {fmt_dec(r)} ₽\n\n"
                   "Можно отправить ещё число.")


async def do_promo(m: Message, code: str):
    try:
        g = activate_promo(m.from_user.id, code)
    except BotError as e:
        return await m.answer(f"❌ {e}")
    await m.answer(f"🎉 Промокод активирован! Начислено <b>{fmt_g(g)}</b>.")


@flow.message(PromoS.code)
async def promo_input(m: Message, state: FSMContext):
    await state.clear()
    await do_promo(m, m.text)


@flow.callback_query(F.data == "home")
async def cb_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.answer()
    if cb.message:
        await html_answer(cb.message, "🏠 <b>Меню</b>\n\n" + welcome_text(), reply_markup=main_kb())
        try:
            await cb.message.delete()
        except TelegramAPIError:
            pass


@flow.callback_query(F.data == "close")
async def cb_close(cb: CallbackQuery):
    await cb.answer()
    try:
        await cb.message.delete()
    except TelegramAPIError:
        pass


@flow.callback_query(F.data == "nolink")
async def cb_nolink(cb: CallbackQuery):
    await cb.answer("Ссылка пока не настроена администратором. Обратитесь в поддержку.", show_alert=True)


@flow.callback_query(F.data == "norules")
async def cb_norules(cb: CallbackQuery):
    await cb.answer("Ссылка на правила пока не настроена.", show_alert=True)


@flow.callback_query(F.data.startswith("faq:"))
async def cb_faq(cb: CallbackQuery):
    i = int(cb.data.split(":")[1])
    await cb.answer()
    if 0 <= i < len(FAQ):
        kb = InlineKeyboardMarkup(inline_keyboard=[[url_btn("🛟 Поддержка", get_setting("support_url"))]])
        await cb.message.answer(f"❓ <b>{FAQ[i][0]}</b>\n\n{FAQ[i][1]}", reply_markup=kb)


@flow.callback_query(F.data == "hist")
async def cb_hist(cb: CallbackQuery):
    await cb.answer()
    await cb.message.answer(history_text(cb.from_user.id))


@flow.callback_query(F.data == "promo")
async def cb_promo(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.set_state(PromoS.code)
    await cb.message.answer("🎁 Введите промокод:", reply_markup=home_kb())


@flow.callback_query(F.data.startswith("calc:"))
async def cb_calc(cb: CallbackQuery, state: FSMContext):
    mode = cb.data.split(":")[1]
    await cb.answer()
    await state.set_state(CalcS.input)
    await state.update_data(mode=mode)
    await cb.message.answer("🪙 Введите количество Gold — покажу цену в ₽:" if mode == "g"
                            else "💰 Введите сумму в рублях — покажу, сколько это G:")


def _own_open(kind: str, oid: int, uid: int, statuses=("awaiting_payment", "checking")):
    o = get_order(kind, oid)
    if o is None or o["user_id"] != uid or o["status"] not in statuses:
        return None
    return o


def _parse_kind(data: str):
    p = data.split(":")
    kind = p[1]
    if kind not in TABLES:
        raise ValueError
    return kind, int(p[2]), p


@flow.callback_query(F.data.startswith("pm:"))
async def cb_pay_method(cb: CallbackQuery):
    try:
        kind, oid, p = _parse_kind(cb.data)
        method = p[3]
        assert method in ("card", "sbp")
    except Exception:
        return await cb.answer("Ошибка данных.", show_alert=True)
    o = _own_open(kind, oid, cb.from_user.id)
    if not o:
        return await cb.answer("Заявка недоступна или уже закрыта.", show_alert=True)
    if not get_setting("card_url" if method == "card" else "sbp_url"):
        return await cb.answer("Ссылка на этот способ оплаты пока не настроена. Обратитесь в поддержку.", show_alert=True)
    DB.execute(f"UPDATE {TABLES[kind]} SET method=? WHERE id=? AND status IN ('awaiting_payment','checking')", (method, oid))
    await cb.answer()
    await cb.message.edit_reply_markup(reply_markup=pay_kb(kind, oid, method))


@flow.callback_query(F.data.startswith("pb:"))
async def cb_pay_back(cb: CallbackQuery):
    try:
        kind, oid, _ = _parse_kind(cb.data)
    except Exception:
        return await cb.answer("Ошибка данных.", show_alert=True)
    if not _own_open(kind, oid, cb.from_user.id):
        return await cb.answer("Заявка недоступна.", show_alert=True)
    await cb.answer()
    await cb.message.edit_reply_markup(reply_markup=pay_kb(kind, oid))


@flow.callback_query(F.data.startswith("pp:"))
async def cb_proof(cb: CallbackQuery, state: FSMContext):
    try:
        kind, oid, _ = _parse_kind(cb.data)
    except Exception:
        return await cb.answer("Ошибка данных.", show_alert=True)
    if kind == "wd" or not _own_open(kind, oid, cb.from_user.id):
        return await cb.answer("Заявка недоступна или уже закрыта.", show_alert=True)
    await cb.answer()
    await state.set_state(ProofS.photo)
    await state.update_data(kind=kind, oid=oid)
    await cb.message.answer(f"📸 Отправьте скриншот оплаты по заявке №{oid} (фотографией).", reply_markup=home_kb())


@flow.callback_query(F.data.startswith("pc:"))
async def cb_cancel_order(cb: CallbackQuery):
    try:
        kind, oid, _ = _parse_kind(cb.data)
    except Exception:
        return await cb.answer("Ошибка данных.", show_alert=True)
    cur = DB.execute(f"UPDATE {TABLES[kind]} SET status='rejected', reason='Отменено пользователем', processed_at=? "
                     "WHERE id=? AND user_id=? AND status='awaiting_payment'", (now(), oid, cb.from_user.id))
    if cur.rowcount != 1:
        return await cb.answer("Заявку уже нельзя отменить.", show_alert=True)
    await cb.answer("Заявка отменена")
    await edit_any(cb, f"🗑 Заявка №{oid} отменена.", None)


@flow.callback_query(F.data.startswith("bpay:"))
async def cb_buy_balance(cb: CallbackQuery):
    oid = int(cb.data.split(":")[1])
    try:
        with tx():
            o = get_order("buy", oid)
            if o is None or o["user_id"] != cb.from_user.id:
                raise BotError("Заявка не найдена.")
            cur = DB.execute("UPDATE purchases SET status='done', method='balance', processed_at=? "
                             "WHERE id=? AND status='awaiting_payment'", (now(), oid))
            if cur.rowcount != 1:
                raise AlreadyProcessed("Заявка уже обработана.")
            apply_balance(o["user_id"], o["gold"], -o["amount_kop"], "buy_balance",
                          f"Покупка №{oid} за баланс", f"buy:{oid}")
    except AlreadyProcessed as e:
        return await cb.answer(str(e), show_alert=True)
    except BotError as e:
        msg = str(e)
        if "Недостаточно" in msg:
            msg = "Недостаточно рублей на балансе. Пополните баланс или оплатите другим способом."
        return await cb.answer(msg, show_alert=True)
    await cb.answer("Готово!")
    await edit_any(cb, f"✅ <b>Покупка №{oid} оплачена с баланса.</b>\nЗачислено: <b>{fmt_g(o['gold'])}</b>. "
                       f"Списано: {fmt_rub(o['amount_kop'])}.", None)


@adm.message(Command("admin"))
async def cmd_admin(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🛠 <b>Админ-панель Trash Gold</b>\n\n"
                   f"💱 Курс: 1 G = <b>{fmt_dec(rate())} ₽</b>", reply_markup=admin_kb())


@adm.message(Command("addadmin"))
async def cmd_addadmin(m: Message):
    if m.from_user.id not in ADMIN_IDS:
        return await m.answer("⛔ Только главный админ (из ADMIN_IDS).")
    p = (m.text or "").split()
    if len(p) != 2 or not p[1].isdigit():
        return await m.answer("Использование: /addadmin <code>TelegramID</code>")
    DB.execute("INSERT OR IGNORE INTO admins(user_id,added_at) VALUES(?,?)", (int(p[1]), now()))
    await m.answer(f"✅ Админ {p[1]} добавлен.")


@adm.message(Command("deladmin"))
async def cmd_deladmin(m: Message):
    if m.from_user.id not in ADMIN_IDS:
        return await m.answer("⛔ Только главный админ (из ADMIN_IDS).")
    p = (m.text or "").split()
    if len(p) != 2 or not p[1].isdigit() or int(p[1]) in ADMIN_IDS:
        return await m.answer("Использование: /deladmin <code>TelegramID</code> (главных админов удалить нельзя).")
    DB.execute("DELETE FROM admins WHERE user_id=?", (int(p[1]),))
    await m.answer(f"✅ Админ {p[1]} удалён.")


@adm.message(F.text == A_STATS)
async def a_stats(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(stats_text())


@adm.message(F.text == A_RATE)
async def a_rate(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(AdminS.rate)
    await m.answer(f"💱 Текущий курс: 1 G = <b>{fmt_dec(rate())} ₽</b>\n\nВведите новый курс (например <code>0.63</code>):")


@adm.message(AdminS.rate)
async def a_rate_set(m: Message, state: FSMContext):
    try:
        v = validate_setting("gold_rate", m.text or "")
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    set_setting("gold_rate", v)
    await state.clear()
    await m.answer(f"✅ Курс успешно изменён.\n\nНовый курс: 1 G = <b>{fmt_dec(Decimal(v))} ₽</b>")


def sbp_kb() -> InlineKeyboardMarkup:
    b = IKB()
    b.button(text="✏️ Добавить / изменить", callback_data="st:sbp_url")
    b.button(text="🗑 Удалить", callback_data="sbpdel")
    b.adjust(2)
    return b.as_markup()


@adm.message(F.text == A_SBP)
async def a_sbp(m: Message, state: FSMContext):
    await state.clear()
    cur = get_setting("sbp_url")
    await m.answer(f"🔗 <b>Ссылка СБП</b>\n\nТекущая: {esc(cur) if cur else '— не задана —'}", reply_markup=sbp_kb(),
                   disable_web_page_preview=True)


@adm.callback_query(F.data == "sbpdel")
async def cb_sbpdel(cb: CallbackQuery):
    set_setting("sbp_url", "")
    await cb.answer("Ссылка удалена")
    await edit_any(cb, "🔗 <b>Ссылка СБП</b>\n\nТекущая: — не задана —", sbp_kb())


@adm.message(F.text == A_USERS)
async def a_users(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(AdminS.search)
    n = DB.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    await m.answer(f"👥 Пользователей: <b>{n}</b>\n\nВведите Telegram ID или @username для поиска:")


@adm.message(AdminS.search)
async def a_user_find(m: Message, state: FSMContext):
    u = find_user(m.text or "")
    if not u:
        return await m.answer("❌ Пользователь не найден. Попробуйте ещё раз (ID или @username):")
    await state.clear()
    text, kb = user_card(u)
    await m.answer(text, reply_markup=kb)


@adm.callback_query(F.data.regexp(r"^u[gsr]:\d+$"))
async def cb_user_adjust(cb: CallbackQuery, state: FSMContext):
    act, uid = cb.data[:2], int(cb.data.split(":")[1])
    if not get_user(uid):
        return await cb.answer("Пользователь не найден", show_alert=True)
    mode = {"ug": "gold_add", "us": "gold_sub", "ur": "rub"}[act]
    await cb.answer()
    await state.set_state(AdminS.adjust)
    await state.update_data(uid=uid, mode=mode)
    hint = {"gold_add": "сколько Gold начислить", "gold_sub": "сколько Gold списать",
            "rub": "сумму в ₽ со знаком: <code>+100</code> — пополнить, <code>-50</code> — списать"}[mode]
    await cb.message.answer(f"Пользователь <code>{uid}</code>. Введите {hint}:")


@adm.message(AdminS.adjust)
async def a_adjust_do(m: Message, state: FSMContext):
    d = await state.get_data()
    uid, mode = d["uid"], d["mode"]
    try:
        amount = parse_signed_rub(m.text or "") if mode == "rub" else Decimal(parse_int(m.text or "", 1, MAX_GOLD))
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    try:
        u, text = admin_adjust(uid, mode, amount, m.from_user.id)
    except BotError as e:
        return await m.answer(f"❌ {e}")
    await state.clear()
    card, kb = user_card(u)
    await m.answer("✅ Выполнено.\n\n" + card, reply_markup=kb)
    await safe_send(uid, text)


@adm.callback_query(F.data.regexp(r"^u[bu]:\d+$"))
async def cb_user_ban(cb: CallbackQuery):
    act, uid = cb.data[:2], int(cb.data.split(":")[1])
    if is_admin(uid):
        return await cb.answer("Нельзя блокировать администратора", show_alert=True)
    if not get_user(uid):
        return await cb.answer("Пользователь не найден", show_alert=True)
    DB.execute("UPDATE users SET banned=? WHERE id=?", (1 if act == "ub" else 0, uid))
    await cb.answer("Заблокирован" if act == "ub" else "Разблокирован")
    text, kb = user_card(get_user(uid))
    await edit_any(cb, text, kb)
    await safe_send(uid, "🚫 Ваш аккаунт заблокирован." if act == "ub" else "✅ Ваш аккаунт разблокирован.")


@adm.callback_query(F.data.regexp(r"^uh:\d+$"))
async def cb_user_hist(cb: CallbackQuery):
    await cb.answer()
    await cb.message.answer(history_text(int(cb.data.split(":")[1]), 25))


@adm.message(F.text == A_GIVE)
async def a_give(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(AdminS.give_id)
    await m.answer("➕ <b>Начисление Gold</b>\n\nВведите Telegram ID пользователя:")


@adm.message(AdminS.give_id)
async def a_give_id(m: Message, state: FSMContext):
    u = find_user(m.text or "")
    if not u:
        return await m.answer("❌ Пользователь не найден. Введите Telegram ID ещё раз:")
    await state.update_data(uid=u["id"])
    await state.set_state(AdminS.give_amount)
    await m.answer(f"Пользователь: {uname(u)}\nВведите количество Gold:")


@adm.message(AdminS.give_amount)
async def a_give_amount(m: Message, state: FSMContext):
    try:
        g = parse_int(m.text or "", 1, MAX_GOLD)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    uid = (await state.get_data())["uid"]
    await state.clear()
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        IB(text="✅ Подтвердить", callback_data=f"gv:{uid}:{g}"),
        IB(text="✖️ Отмена", callback_data="close")]])
    await m.answer(f"Начислить <b>{fmt_g(g)}</b> пользователю <code>{uid}</code>?", reply_markup=kb)


@adm.callback_query(F.data.regexp(r"^gv:\d+:\d+$"))
async def cb_give_ok(cb: CallbackQuery):
    _, uid, g = cb.data.split(":")
    try:
        u, text = admin_adjust(int(uid), "gold_add", Decimal(int(g)), cb.from_user.id)
    except BotError as e:
        return await cb.answer(str(e), show_alert=True)
    await cb.answer("Начислено")
    await edit_any(cb, f"✅ Начислено {fmt_g(g)} пользователю <code>{uid}</code>. Баланс: {fmt_g(u['gold'])}.", None)
    await safe_send(int(uid), text)


@adm.message(F.text == A_PAY)
async def a_pay(m: Message, state: FSMContext):
    await state.clear()
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [IB(text="💰 Пополнения", callback_data="ol:dep:p:0"),
         IB(text="🛒 Покупки Gold", callback_data="ol:buy:p:0")]])
    await m.answer("🧾 <b>Заявки на оплату</b>\nВыберите тип:", reply_markup=kb)


@adm.message(F.text == A_WD)
async def a_wd(m: Message, state: FSMContext):
    await state.clear()
    text, kb = list_view("wd", "p", 0)
    await m.answer(text, reply_markup=kb)


@adm.callback_query(F.data.regexp(r"^ol:(dep|buy|wd):[apdr]:\d+$"))
async def cb_list(cb: CallbackQuery):
    _, kind, flt, page = cb.data.split(":")
    await cb.answer()
    text, kb = list_view(kind, flt, int(page))
    await edit_any(cb, text, kb)


@adm.callback_query(F.data.regexp(r"^po:(dep|buy|wd):\d+$"))
async def cb_open(cb: CallbackQuery):
    _, kind, oid = cb.data.split(":")
    o = get_order(kind, int(oid))
    if not o:
        return await cb.answer("Заявка не найдена", show_alert=True)
    await cb.answer()
    text, kb = order_text(kind, o), order_admin_kb(kind, o)
    if o["proof"]:
        await cb.message.answer_photo(o["proof"], caption=text, reply_markup=kb)
    else:
        await cb.message.answer(text, reply_markup=kb)


@adm.callback_query(F.data.regexp(r"^ok:(dep|buy|wd):\d+$"))
async def cb_ok(cb: CallbackQuery):
    _, kind, oid = cb.data.split(":")
    oid = int(oid)
    try:
        uid, msg, ref = finalize_order(kind, oid, cb.from_user.id)
    except AlreadyProcessed:
        o = get_order(kind, oid)
        await cb.answer("⚠️ Заявка уже обработана", show_alert=True)
        return await edit_any(cb, order_text(kind, o), order_admin_kb(kind, o))
    except BotError as e:
        return await cb.answer(f"❌ {e}", show_alert=True)
    await cb.answer("Готово")
    await edit_any(cb, order_text(kind, get_order(kind, oid)), None)
    await safe_send(uid, msg)
    if ref:
        await safe_send(ref[0], f"👥 <b>Бонус за друга!</b>\n+{fmt_rub(ref[1])} на ваш баланс "
                                f"за {'пополнение' if kind == 'dep' else 'покупку'} приглашённого друга.")


@adm.callback_query(F.data.regexp(r"^no:(dep|buy|wd):\d+$"))
async def cb_no(cb: CallbackQuery, state: FSMContext):
    _, kind, oid = cb.data.split(":")
    o = get_order(kind, int(oid))
    if not o or o["status"] not in OPEN:
        return await cb.answer("⚠️ Заявка уже обработана", show_alert=True)
    await cb.answer()
    await state.set_state(AdminS.reason)
    await state.update_data(kind=kind, oid=int(oid))
    await cb.message.answer(f"❌ Отклонение заявки №{oid}.\nВведите причину (или «-», чтобы без причины):")


@adm.message(AdminS.reason)
async def a_reason(m: Message, state: FSMContext):
    d = await state.get_data()
    reason = (m.text or "").strip()
    reason = "" if reason == "-" else reason[:500]
    try:
        uid, msg = reject_order(d["kind"], d["oid"], m.from_user.id, reason)
    except AlreadyProcessed:
        await state.clear()
        return await m.answer("⚠️ Заявка уже обработана.")
    except BotError as e:
        await state.clear()
        return await m.answer(f"❌ {e}")
    await state.clear()
    await m.answer(f"✅ Заявка №{d['oid']} отклонена.")
    await safe_send(uid, msg)


@adm.message(F.text == A_PROMO)
async def a_promo(m: Message, state: FSMContext):
    await state.clear()
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        IB(text="➕ Создать", callback_data="pnew"),
        IB(text="📋 Список / отключить", callback_data="plist")]])
    await m.answer("🎁 <b>Промокоды</b>", reply_markup=kb)


@adm.callback_query(F.data == "pnew")
async def cb_pnew(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.set_state(AdminS.promo_code)
    await cb.message.answer("Введите название промокода (латиница/цифры/_/-, 3–32 символа):")


@adm.message(AdminS.promo_code)
async def a_promo_code(m: Message, state: FSMContext):
    code = (m.text or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9_\-]{3,32}", code):
        return await m.answer("⚠️ Только латиница, цифры, _ и -, длина 3–32.")
    if DB.execute("SELECT 1 FROM promo_codes WHERE code=?", (code,)).fetchone():
        return await m.answer("⚠️ Такой промокод уже существует.")
    await state.update_data(code=code)
    await state.set_state(AdminS.promo_gold)
    await m.answer("Сколько Gold даёт промокод?")


@adm.message(AdminS.promo_gold)
async def a_promo_gold(m: Message, state: FSMContext):
    try:
        g = parse_int(m.text or "", 1, MAX_GOLD)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    await state.update_data(gold=g)
    await state.set_state(AdminS.promo_uses)
    await m.answer("Сколько всего активаций (число пользователей)?")


@adm.message(AdminS.promo_uses)
async def a_promo_uses(m: Message, state: FSMContext):
    try:
        n = parse_int(m.text or "", 1, 1_000_000)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    await state.update_data(uses=n)
    await state.set_state(AdminS.promo_days)
    await m.answer("Срок действия в днях? (<code>0</code> — бессрочно)")


@adm.message(AdminS.promo_days)
async def a_promo_days(m: Message, state: FSMContext):
    t = _clean(m.text or "")
    if not t.isdigit() or int(t) > 3650:
        return await m.answer("⚠️ Введите целое число дней от 0 до 3650.")
    d = await state.get_data()
    days = int(t)
    exp = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S") if days else None
    try:
        DB.execute("INSERT INTO promo_codes(code,gold,max_uses,expires_at,created) VALUES(?,?,?,?,?)",
                   (d["code"], d["gold"], d["uses"], exp, now()))
    except sqlite3.IntegrityError:
        await state.clear()
        return await m.answer("⚠️ Такой промокод уже существует.")
    await state.clear()
    await m.answer(f"✅ Промокод создан\n\n🎁 <code>{d['code']}</code>\n🪙 {fmt_g(d['gold'])} • активаций: {d['uses']}\n"
                   f"⏳ До: {exp or 'бессрочно'}")


def promo_list_kb():
    rows = DB.execute("SELECT * FROM promo_codes ORDER BY id DESC LIMIT 30").fetchall()
    b = IKB()
    for p in rows:
        b.button(text=f"{'🟢' if p['active'] else '🔴'} {p['code']} • {p['gold']}G • {p['used']}/{p['max_uses']}",
                 callback_data=f"pt:{p['id']}")
    b.adjust(1)
    return b.as_markup(), len(rows)


@adm.callback_query(F.data == "plist")
async def cb_plist(cb: CallbackQuery):
    await cb.answer()
    kb, n = promo_list_kb()
    await cb.message.answer("📋 Промокоды (нажмите, чтобы включить/отключить):" if n else "Промокодов пока нет.",
                            reply_markup=kb if n else None)


@adm.callback_query(F.data.regexp(r"^pt:\d+$"))
async def cb_ptoggle(cb: CallbackQuery):
    DB.execute("UPDATE promo_codes SET active=1-active WHERE id=?", (int(cb.data.split(":")[1]),))
    await cb.answer("Изменено")
    kb, _ = promo_list_kb()
    try:
        await cb.message.edit_reply_markup(reply_markup=kb)
    except TelegramBadRequest:
        pass


def settings_view():
    L = ["⚙️ <b>Настройки</b>", SEP]
    b = IKB()
    for key, label, typ in SETTINGS_META:
        v = get_setting(key)
        if typ == "bool":
            shown = "✅ да" if v == "1" else "⛔ нет"
        elif typ == "text":
            shown = esc(v[:40] + ("…" if len(v) > 40 else "")).replace("\n", " ")
        else:
            shown = esc(v) if v else "— не задано —"
        L.append(f"{label}: <b>{shown}</b>" if typ != "url" else f"{label}: {shown}")
        b.button(text=label, callback_data=f"st:{key}")
    b.adjust(2)
    b.row(IB(text="✖️ Закрыть", callback_data="close"))
    return "\n".join(L), b.as_markup()


@adm.message(F.text == A_SET)
async def a_settings(m: Message, state: FSMContext):
    await state.clear()
    text, kb = settings_view()
    await m.answer(text, reply_markup=kb, disable_web_page_preview=True)


@adm.callback_query(F.data.startswith("st:"))
async def cb_setting(cb: CallbackQuery, state: FSMContext):
    key = cb.data.split(":", 1)[1]
    if key not in META:
        return await cb.answer("Неизвестная настройка", show_alert=True)
    label, typ = META[key]
    if typ == "bool":
        set_setting(key, "0" if get_setting(key) == "1" else "1")
        await cb.answer("Переключено")
        text, kb = settings_view()
        return await edit_any(cb, text, kb)
    await cb.answer()
    await state.set_state(AdminS.setting)
    await state.update_data(key=key)
    hint = {"url": "Отправьте ссылку (https://… или @username). «-» — удалить.",
            "dec": "Отправьте число.", "int": "Отправьте целое число.",
            "text": "Отправьте новый текст (HTML разрешён). Подстановки: {gold} {price} {skin} — для вывода."}[typ]
    await cb.message.answer(f"{label}\nТекущее значение:\n<code>{esc(get_setting(key)) or '—'}</code>\n\n{hint}",
                            disable_web_page_preview=True)


@adm.message(AdminS.setting)
async def a_setting_set(m: Message, state: FSMContext):
    key = (await state.get_data())["key"]
    raw = m.html_text if META[key][1] == "text" else (m.text or "")
    try:
        v = validate_setting(key, raw)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    set_setting(key, v)
    await state.clear()
    extra = f"\n\nНовый курс: 1 G = <b>{fmt_dec(Decimal(v))} ₽</b>" if key == "gold_rate" else ""
    await m.answer(f"✅ Сохранено: {META[key][0]}{extra}")


def parse_buttons(raw: str):
    if raw.strip() == "-":
        return []
    out = []
    for line in raw.strip().splitlines():
        if "|" not in line:
            raise ValueError("Формат строки: Название | https://ссылка")
        t, u = line.split("|", 1)
        t = t.strip()
        if not t or len(t) > 60:
            raise ValueError("Название кнопки: 1–60 символов.")
        out.append([t, norm_url(u)])
    if len(out) > 8:
        raise ValueError("Не более 8 кнопок.")
    return out


def bc_markup(buttons):
    if not buttons:
        return None
    return InlineKeyboardMarkup(inline_keyboard=[[IB(text=t, url=u)] for t, u in buttons])


async def bc_send(chat_id: int, d: dict):
    kb = bc_markup(d.get("buttons"))
    if d["kind"] == "photo":
        return await bot.send_photo(chat_id, d["file_id"], caption=d["body"] or None, reply_markup=kb)
    return await bot.send_message(chat_id, d["body"], reply_markup=kb, disable_web_page_preview=True)


@adm.message(F.text == A_BC)
async def a_bc(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(BcS.content)
    await m.answer("📣 <b>Рассылка</b>\n\nОтправьте сообщение для рассылки: текст или фото с подписью "
                   "(форматирование сохранится). Для отмены — «🏠 Главное меню» или /cancel.")


@adm.message(BcS.content, F.photo)
async def bc_photo(m: Message, state: FSMContext):
    await state.update_data(kind="photo", file_id=m.photo[-1].file_id, body=m.html_text or "")
    await state.set_state(BcS.buttons)
    await m.answer("Добавьте inline-кнопки: каждая строка — <code>Название | https://ссылка</code>.\nИли «-» без кнопок.")


@adm.message(BcS.content, F.text)
async def bc_text(m: Message, state: FSMContext):
    await state.update_data(kind="text", file_id=None, body=m.html_text)
    await state.set_state(BcS.buttons)
    await m.answer("Добавьте inline-кнопки: каждая строка — <code>Название | https://ссылка</code>.\nИли «-» без кнопок.")


@adm.message(BcS.buttons, F.text)
async def bc_buttons(m: Message, state: FSMContext):
    try:
        btns = parse_buttons(m.text)
    except ValueError as e:
        return await m.answer(f"⚠️ {e}")
    await state.update_data(buttons=btns)
    d = await state.get_data()
    await state.set_state(BcS.confirm)
    n = DB.execute("SELECT COUNT(*) FROM users WHERE banned=0").fetchone()[0]
    try:
        await bc_send(m.chat.id, d)
    except TelegramAPIError as e:
        await state.clear()
        return await m.answer(f"❌ Не удалось сформировать сообщение: {esc(e)}\nПроверьте HTML-разметку.")
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        IB(text=f"🚀 Отправить ({n})", callback_data="bc:go"),
        IB(text="✖️ Отмена", callback_data="bc:no")]])
    await m.answer("👆 Так увидят пользователи. Начать рассылку?", reply_markup=kb)


@adm.callback_query(BcS.confirm, F.data == "bc:no")
async def bc_cancel(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.answer("Отменено")
    await edit_any(cb, "✖️ Рассылка отменена.", None)


_bg_tasks: set = set()


@adm.callback_query(BcS.confirm, F.data == "bc:go")
async def bc_go(cb: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    await state.clear()
    await cb.answer("Запущено")
    await edit_any(cb, "🚀 Рассылка запущена. Отчёт придёт по завершении.", None)
    t = asyncio.create_task(run_broadcast(cb.from_user.id, d))
    _bg_tasks.add(t)
    t.add_done_callback(_bg_tasks.discard)


async def run_broadcast(admin_id: int, d: dict):
    ids = [r[0] for r in DB.execute("SELECT id FROM users WHERE banned=0")]
    ok = blocked = err = 0
    for uid in ids:
        for attempt in (1, 2):
            try:
                await bc_send(uid, d)
                ok += 1
            except TelegramRetryAfter as e:
                await asyncio.sleep(e.retry_after + 0.5)
                continue
            except TelegramForbiddenError:
                blocked += 1
            except TelegramAPIError:
                err += 1
            break
        else:
            err += 1
        await asyncio.sleep(0.04)
    await safe_send(admin_id, f"📣 <b>Рассылка завершена</b>\n{SEP}\n✅ Успешно: {ok}\n🚫 Заблокировали бота: {blocked}\n"
                              f"⚠️ Ошибки: {err}\n👥 Всего: {len(ids)}")


@adm.message(StateFilter(BcS.content, BcS.buttons))
async def bc_bad(m: Message):
    await m.answer("⚠️ Отправьте то, что просит бот (текст/фото), либо нажмите «🏠 Главное меню».")


@fb.message()
async def unknown(m: Message, state: FSMContext):
    if await state.get_state():
        return await m.answer("⚠️ Не понял. Отправьте то, что запрошено, или нажмите «🏠 Главное меню».")
    if (m.text or "").startswith("/"):
        return await m.answer("❓ Неизвестная команда. Используйте кнопки меню.", reply_markup=main_kb())
    await m.answer("❓ Не понял вас. Выберите раздел в меню 👇", reply_markup=main_kb())


@fb.callback_query()
async def unknown_cb(cb: CallbackQuery):
    await cb.answer("Действие недоступно или устарело.", show_alert=True)


async def on_error(event: ErrorEvent):
    log.exception("Unhandled error: %s", event.exception)
    upd = event.update
    try:
        if upd.message:
            await upd.message.answer("⚠️ Произошла ошибка. Попробуйте ещё раз или напишите в поддержку.")
        elif upd.callback_query:
            await upd.callback_query.answer("⚠️ Произошла ошибка. Попробуйте ещё раз.", show_alert=True)
    except Exception:
        pass
    return True


async def main():
    global bot
    if not BOT_TOKEN:
        print("❌ Не задан BOT_TOKEN. Создайте файл .env (см. .env.example) или задайте переменную окружения.")
        sys.exit(1)
    if not ADMIN_IDS:
        log.warning("ADMIN_IDS пуст — админ-панель будет недоступна. Укажите ID в .env")
    init_db()
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    bot.session.middleware(PremiumMW())
    bot.session.middleware(TrackMW())
    dp = Dispatcher(storage=MemoryStorage())
    for r in (nav, adm, flow, fb):
        r.message.filter(F.chat.type == "private")
    mw = UserMW()
    dp.message.outer_middleware(mw)
    dp.callback_query.outer_middleware(mw)
    cmw = CleanMW()
    dp.message.outer_middleware(cmw)
    dp.callback_query.outer_middleware(cmw)
    dp.include_routers(nav, adm, flow, fb)
    dp.errors.register(on_error)
    me = await bot.get_me()
    global BOT_USERNAME
    BOT_USERNAME = me.username or ""
    log.info("Trash Gold запущен как @%s", me.username)
    await bot.delete_webhook(drop_pending_updates=False)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
